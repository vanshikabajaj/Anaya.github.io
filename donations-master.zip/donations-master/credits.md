# Credits - `yourdonation.rocks`

- [Core Developer](https://nikolaskama.me) - [Nikolaos Kamarinakis](mailto:nikolaskam@gmail.com) (k4m4)

- [Image 3 (edited)](https://thenounproject.com) - by Luis Rodrigues
- [Image 6 (edited)](https://thenounproject.com) - by Maxim David

- [Bootstrap (CCA 3.0 license)](https://html5up.net/)
